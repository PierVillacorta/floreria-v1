import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App.tsx";

import { createBrowserRouter, RouterProvider } from "react-router-dom";

import NotFoundPage from "./components/NotFoundPage.tsx";

import { InfoProduct } from "./pages/InfoProduct.tsx";
import Layout from "./components/Layout.tsx";
import { Categories } from "./pages/Categories.tsx";
import { Checkout } from "./pages/payments/Chekout.tsx";
import { PaymentError } from "./pages/payments/PaymentError.tsx";
import { PaymentSuccess } from "./pages/payments/PaymentSucess.tsx";
import { AdminLayout } from "./pages/admin/AdminLayaout.tsx";
import { AdminUsers } from "./pages/admin/AdminUsers.tsx";
import { AdminProducts } from "./pages/admin/AdminProducts.tsx";
import { Offers } from "./pages/Offers.tsx";
import { AdminCategories } from "./pages/admin/AdminCategories.tsx";
import { BlogsPage } from "./pages/BlogPage.tsx";
import { BlogDetail } from "./pages/BlogDetail.tsx";
import { Cart } from "./pages/Cart.tsx";
import { About } from "./pages/About.tsx";
import { Login } from "./pages/Login.tsx";
import { Register } from "./pages/Register.tsx";
import { GoogleOAuthProvider } from "@react-oauth/google";
import { MyOrders } from "./pages/MyOrders.tsx";
import { AdminOrders } from "./pages/admin/AdminOrders.tsx";
import { AdminHome } from "./pages/admin/AdminHome.tsx";
import { RequireRole } from "./components/RequireRole.tsx";
import { useAuthStore } from "./store/authStore.ts";
import { configureApi } from "./utils/api.ts";


configureApi({
  getToken: () => useAuthStore.getState().token,
  onUnauthorized: () => useAuthStore.getState().logout(),
});

const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />,
    children: [
      { index: true, element: <App /> },
      { path: "cart", element: <Cart /> },
      { path: "categories", element: <Categories /> },
      { path: "checkout", element: <Checkout /> },
      { path: "payment-success", element: <PaymentSuccess /> },
      { path: "payment-error", element: <PaymentError /> },
      { path: "about", element: <About /> },
      { path: "login", element: <Login /> },
      { path: "register", element: <Register /> },
      { path: "product/:product_id", element: <InfoProduct /> },
      { path: "offers", element: <Offers /> },
      { path: "blogs", element: <BlogsPage /> },
      { path: "blogs/:id", element: <BlogDetail /> },
      { path: "my-orders", element: <MyOrders /> },
      {
        path: "admin",
        element: <AdminLayout />,
        children: [
          { index: true, element: <AdminHome /> },
          { path: "orders", element: <AdminOrders /> },
          { path: "products", element: <AdminProducts /> },
          {
            //Evita que un vendedor entre como admin con la url redirigiendo a /admin
            element: <RequireRole roles={["ADMIN"]} redirectTo="/admin" />,
            children: [
              { path: "users", element: <AdminUsers /> },
              { path: "categories", element: <AdminCategories /> },
            ],
          },
        ],
      },
      { path: "*", element: <NotFoundPage /> },
    ],
  },
]);

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <GoogleOAuthProvider clientId={import.meta.env.VITE_GOOGLE_CLIENT_ID}>
      <RouterProvider router={router} />
    </GoogleOAuthProvider>
  </StrictMode>,
);
